


<?php $__env->startSection('content'); ?>
<div class="d-flex flex-row w-100 align-items-center justify-content-between">
  <div class="d-flex flex-row">
    <a type="button" class="btn btn-info mr-3" style="width: fit-content;" href="<?php echo e(route('product.all')); ?>">Back</a>
    <h3><?php echo e($product->product_name); ?> Details</h3>
  </div>
  <div class="d-flex flex-row">
    <a
      type="button"
      class="btn btn-warning mr-3"
      href="<?php echo e(route('product.edit', ['id' => $product->id])); ?>"
    >
      Edit
    </a>
    <form style="display:inline;" action="<?php echo e(route('product.delete', ['id' => $product->id])); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-danger" onclick="return confirm('Are You Sure To Delete ?')">Delete</button>
    </form>
  </div>
</div>
<div class="d-flex flex-row container justify-content-start container p-0 my-4">
  <div class="col-4 p-0">
    <img class="col-8 shadow rounded" src="<?php echo e(asset('storage/' .$product->product_image->image_path)); ?>">
  </div>
  <div class="col-8">
    <h5><strong>Nama Produk:</strong> <?php echo e($product->product_name); ?></h5>
    <h5><strong>Category:</strong> <?php echo e($product->categories[0]->category_name); ?></h5>
    <h5><strong>Harga:</strong> <?php echo e($product->price); ?></h5>
    <h5><strong>Berat:</strong> <?php echo e($product->weight); ?></h5>
    <h5><strong>Stock:</strong> <?php echo e($product->stock); ?></h5>
    <h5><strong>Deskripsi:</strong> <br> <?php echo e($product->description); ?></h5>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mentoring\Laravel\commerce\resources\views/pages/product/view.blade.php ENDPATH**/ ?>