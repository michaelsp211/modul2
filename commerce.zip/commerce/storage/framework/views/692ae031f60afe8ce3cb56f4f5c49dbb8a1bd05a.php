


<?php $__env->startSection('content'); ?>
<p><?php echo e(product->name); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mentoring\Laravel\commerce\resources\views/pages/product/view_product.blade.php ENDPATH**/ ?>