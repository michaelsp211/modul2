

<?php $__env->startSection('content'); ?>

<div style="container">
  <button 
    class="btn btn-primary float-right"
    type="button"
    data-toggle="modal"
    data-target="#addCategory"
  >
    Add Category
  </button>
</div>

  <table class="table mt-4">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Category</th>
        <th scope="col">Description</th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($category->category_name); ?></td>
          <td><?php echo e($category->description); ?></td>
          <td>
            <a
              type="button"
              class="btn btn-warning"
              data-toggle="modal"
              data-target="#editCategory"
            >
              Edit
            </a>
            <form style="display:inline;" action="<?php echo e(route('category.delete', ['id' => $category->id])); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger" onclick="return confirm('Are You Sure To Delete ?')">Delete</button>
            </form>
          </td>
        </tr>
        <!-- Edit Category Modal  -->
        <div id="editCategory" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Input Category</h4>
              </div>
              <div class="modal-body">
                <form action="<?php echo e(route('category.update')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <input type="hidden" class="form-control" name="id" required="1" value="<?php echo e($category->id); ?>">
                  <div class="form-group">
                    <label>Category Name:</label>
                    <input type="text" class="form-control" name="category_name" required="1" value="<?php echo e($category->category_name); ?>">
                  </div>
                  <div class="form-group">
                    <label>Description:</label>
                    <input type="text" class="form-control" name="description" required="1" value="<?php echo e($category->description); ?>">
                  </div>
                  <div class="form-group">
                    <button class="btn btn-primary" type="submit">Confirm</button>
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <!-- Add Category Modal  -->
  <div id="addCategory" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Input Category</h4>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('category.create')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Category Name:</label>
              <input type="text" class="form-control" name="category_name" required="1">
            </div>
            <div class="form-group">
              <label>Description:</label>
              <input type="text" class="form-control" name="description" required="1">
            </div>
            <div class="form-group">
              <button class="btn btn-primary" type="submit">Confirm</button>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mentoring\Laravel\commerce\resources\views/pages/category/category.blade.php ENDPATH**/ ?>