

<?php $__env->startSection('content'); ?>

<div style="container">
  <button 
    class="btn btn-primary float-right"
    type="button"
    data-toggle="modal"
    data-target="#addProduct"
  >
    Add Product
  </button>
</div>
  <table class="table mt-4">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Product Name</th>
        <th scope="col">Price</th>
        <th scope="col">Product Rate</th>
        <th scope="col">Stock</th>
        <th scope="col">Weight</th>
        <th scope="col">Category</th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($product->product_name); ?></td>
          <td><?php echo e($product->price); ?></td>
          <td><?php echo e($product->product_rate); ?></td>
          <td><?php echo e($product->stock); ?></td>
          <td><?php echo e($product->weight); ?></td>
          <td>
            <ul style="list-style-type: none; padding: 0;">
            <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($product_category->category_name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </td>
          <td>
            <a
              type="button"
              class="btn btn-info"
              data-toggle="modal"
              data-target="#editProduct"
            >
              View
            </a>
            <a
              type="button"
              class="btn btn-warning"
              data-toggle="modal"
              data-target="#editProduct"
            >
              Edit
            </a>
            <form style="display:inline;" action="<?php echo e(route('category.delete', ['id' => $product->id])); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger" onclick="return confirm('Are You Sure To Delete ?')">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mentoring\Laravel\commerce\resources\views/pages/product.blade.php ENDPATH**/ ?>